package com.example.micromobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.Set;
import java.util.UUID;



public class MainActivity extends AppCompatActivity {

    private static final String TAG = "DEBUG_MA" ;
    double frequence = 440;
    int durationMs = 1000;
    int niveau_declenchement_feux = 50;
    long temps1 = new Date().getTime();
    long temps2 = new Date().getTime();
    float vitesse = 0;
    double sensibilite_angle = 0.3;
    double sensibilite_rayon = 10;
    boolean isAllume = false;
    boolean isGaucher = false;
    double correctionRoue = 1;
    double equilibrageRoues = 197.5;
    ArrayList<Double> vitesse_roue_droite = new ArrayList<>();
    ArrayList<Double> vitesse_roue_gauche = new ArrayList<>();
    String interval_temps;

    EditText editTextBatterie;
    JoystickView joystick1;
    SeekBar speed_regulator;
    Button buttonSendMessage;
    Button buttonBTConnect;
    ImageButton buttonMemory1;
    ImageButton buttonMemory2;
    ImageButton parametre;
    ImageButton buttonReverse;
    ImageButton buttonDanse;
    ToggleButton buttonMemory3;
    Button buttonMemory4;
    Button buttonMemory5;
    Button buttonMemory6;
    Button buttonMemory7;
    Button buttonMemory8;
    Button buttonMemory9;


    EditText editTextSentMessage;
    TextView textViewLuminosite;

    Spinner spinnerBTPairedDevices;

    EditText editTextPopUpLabel;        //servent a changer la frequence du son
    EditText editTextPopUpData;
    Button buttonPopUpSave;
    Button buttonPopUpCancel;
    LinearLayout linearLayoutPopupSaveData;
    PopupWindow popupWindowSaveData;

    EditText reglage_direction;         //correspond a la fenetre parametre
    EditText tanh;
    EditText declenchementFeux;
    Button buttonPopUpSave2;
    Button buttonPopUpCancel2;
    LinearLayout linearLayoutPopupSaveData2;
    PopupWindow popupWindowSaveData2;
    CheckBox checkBoxGaucher;
    Button buttonEquilibrageRoues;
    Button buttonFinTest;
    EditText editTextCorrection;
    ImageButton flecheGauche;
    ImageButton flecheDroite;



    static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothSocket BTSocket = null;
    BluetoothAdapter BTAdaptor = null;
    Set<BluetoothDevice> BTPairedDevices = null;
    boolean bBTConnected = false;
    BluetoothDevice BTDevice = null;
    classBTInitDataCommunication cBTInitSendReceive =null;

    static public final int BT_CON_STATUS_NOT_CONNECTED     =0;
    static public final int BT_CON_STATUS_CONNECTING        =1;
    static public final int BT_CON_STATUS_CONNECTED         =2;
    static public final int BT_CON_STATUS_FAILED            =3;
    static public final int BT_CON_STATUS_CONNECTiON_LOST   =4;
    static public int iBTConnectionStatus = BT_CON_STATUS_NOT_CONNECTED;

    static final int BT_STATE_LISTENING            =1;
    static final int BT_STATE_CONNECTING           =2;
    static final int BT_STATE_CONNECTED            =3;
    static final int BT_STATE_CONNECTION_FAILED    =4;
    static final int BT_STATE_MESSAGE_RECEIVED     =5;




    // Usage:
//    AudioTrack tone = generateTone(440, 250);
//    tone.play();
//
    private AudioTrack generateTone(double freqHz, int durationMs)
    {
        int count = (int)(44100.0 * 2.0 * (durationMs / 1000.0)) & ~1;
        short[] samples = new short[count];
        for(int i = 0; i < count; i += 2){
            short sample = (short)(Math.sin(2 * Math.PI * i / (44100.0 / freqHz)) * 0x7FFF);
            samples[i + 0] = sample;
            samples[i + 1] = sample;
        }
        AudioTrack track = new AudioTrack(AudioManager.STREAM_MUSIC, 44100,
                AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT,
                count * (Short.SIZE / 8), AudioTrack.MODE_STATIC);
        track.write(samples, 0, count);
        return track;
    }

    private void metAjourEquilibrage(double equilibrageRoues)
    {
        if(equilibrageRoues > 50){
            correctionRoue = 1 + 0.2*(equilibrageRoues-50)/100;
        }
        else if(equilibrageRoues < 50){
            correctionRoue = 1 - 0.2*(50 - equilibrageRoues)/100;
        }
        else{
            Log.d(TAG, "= 50");
        }
        Log.d(TAG, "correction roue"+correctionRoue);
        sendMessage("c"+String.valueOf(correctionRoue)+"w");

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        // remove title
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate-Start");


        spinnerBTPairedDevices = findViewById(R.id.idMASpinnerBTPairedDevices);

        joystick1 = findViewById(R.id.joystick);
        editTextBatterie = findViewById(R.id.pourcentageBatterie);
        speed_regulator = findViewById(R.id.speed_regulator);
        buttonBTConnect = findViewById(R.id.idMAButtonConnect);
        buttonMemory1 = findViewById(R.id.idMAButtonStoreData1);
        buttonMemory2 = findViewById(R.id.idMAButtonStoreData2);
        buttonMemory3 = findViewById(R.id.toggleButton);
        buttonMemory4 = findViewById(R.id.idMAButtonStoreData4);
        buttonMemory5 = findViewById(R.id.idMAButtonStoreData5);
        parametre = findViewById(R.id.icon_parametre);
        textViewLuminosite = findViewById(R.id.textViewluminiosite);
        buttonReverse = findViewById(R.id.imageButtonReverse);
        buttonDanse = findViewById(R.id.imageButtonDanse);

        buttonMemory2.setBackgroundResource(R.drawable.feux_black50);


        joystick1.setOnMoveListener(new JoystickView.OnMoveListener() {
            @Override
            public void onMove(int angle, int strength) {
                double theta = (angle*Math.PI/180);
                double gauche = Math.sin(theta + sensibilite_angle);
                double droite = Math.sin(theta - sensibilite_angle);
                double force = ((double) strength)/100;
                double multiplicateur = (1+Math.tanh(sensibilite_rayon*(force-0.5)))/2;
                gauche *= multiplicateur*vitesse;
                int tronq = (int) (gauche*100);
                gauche = ((double)tronq)/100;
                droite *= multiplicateur*vitesse;
                tronq = (int) (droite*100);//1673444965498
                droite = ((double)tronq)/100;//1673444965549
                Log.e(TAG, " gauche : "+gauche+" droite : "+droite);//1673444965599
                Log.e(TAG, "time : "+new Date().getTime());//1673444965649
                sendMessage("d" + String.valueOf(droite) + "w");//1673444965700
                sendMessage("g" + String.valueOf(gauche) + "w");//1673444965727
                vitesse_roue_droite.add(droite);
                vitesse_roue_gauche.add(gauche);

            }
        });


        speed_regulator.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progressValue, boolean b) {
                vitesse = (float) progressValue/(float) seekBar.getMax();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        buttonMemory1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //AudioTrack tone = generateTone(frequence, durationMs);
                //tone.play();
                Toast.makeText(getApplicationContext(), "Micro Momo retourne à la maison, déconnexion iminente", Toast.LENGTH_SHORT).show();
                sendMessage("r");
            }
        });
        buttonMemory1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                Log.d(TAG, "Button Long Press buttonMemory1");
                LayoutInflater layoutInflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View customView = layoutInflater.inflate(R.layout.layoutstoredata,null);
                buttonPopUpCancel = customView.findViewById(R.id.idSDButtonCancel);
                buttonPopUpSave = customView.findViewById(R.id.idSDButtonSave);
                editTextPopUpLabel = customView.findViewById(R.id.idSDEditTextLabel);
                editTextPopUpData = customView.findViewById(R.id.idSDEditTextData);
                editTextPopUpData.setText(String.valueOf(frequence));
                editTextPopUpLabel.setText(String.valueOf(durationMs));
                linearLayoutPopupSaveData = customView.findViewById(R.id.idLLPopupStoreData);
                popupWindowSaveData = new PopupWindow(customView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                popupWindowSaveData.setFocusable(true);
                popupWindowSaveData.update();
                //display the popup window
                popupWindowSaveData.showAtLocation(linearLayoutPopupSaveData, Gravity.CENTER, 0, 0);
                buttonPopUpCancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        popupWindowSaveData.dismiss();
                    }
                });
                buttonPopUpSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(editTextPopUpData.getText().length()<1 || editTextPopUpLabel.getText().length()<1)
                        {
                            Toast.makeText(getApplicationContext(), "Please enter both label and Data", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        frequence = Double.parseDouble(editTextPopUpData.getText().toString());
                        durationMs = Integer.parseInt(editTextPopUpLabel.getText().toString());
                        Toast.makeText(getApplicationContext(), "Nouvelle frequence : "
                                + frequence + " Hz\nNouvelle duree : " + durationMs + " ms", Toast.LENGTH_SHORT).show();
                        popupWindowSaveData.dismiss();
                    }
                });
                return false;
            }
        });




        parametre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Button parametre pressed");
                LayoutInflater layoutInflater = (LayoutInflater) MainActivity.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                View customView = layoutInflater.inflate(R.layout.parametre,null);
                buttonPopUpCancel2 = customView.findViewById(R.id.idSDButtonCancelParameter);
                buttonPopUpSave2 = customView.findViewById(R.id.idSDButtonSaveParameter);
                reglage_direction = customView.findViewById(R.id.reglage_direction);
                tanh = customView.findViewById(R.id.tanh);
                checkBoxGaucher = customView.findViewById(R.id.checkBoxGaucher);
                declenchementFeux = customView.findViewById(R.id.declenchement_des_feux);
                buttonEquilibrageRoues = customView.findViewById(R.id.buttonEquilibrageRoues);
                buttonFinTest = customView.findViewById(R.id.buttonFinTest);
                flecheGauche = customView.findViewById(R.id.imageButtonFlecheGauche);
                editTextCorrection = customView.findViewById(R.id.editTextCorrection);
                flecheDroite = customView.findViewById(R.id.imageButtonFlecheDroite);


                declenchementFeux.setText(String.valueOf(niveau_declenchement_feux));
                reglage_direction.setText(String.valueOf(sensibilite_angle));
                tanh.setText(String.valueOf(sensibilite_rayon));
                editTextCorrection.setText(String.valueOf(equilibrageRoues));
                linearLayoutPopupSaveData2 = customView.findViewById(R.id.idLLPopupParameter);
                popupWindowSaveData2 = new PopupWindow(customView, LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                popupWindowSaveData2.setFocusable(true);
                popupWindowSaveData2.update();
                //display the popup window
                popupWindowSaveData2.showAtLocation(linearLayoutPopupSaveData2, Gravity.CENTER, 0, 0);
                buttonPopUpCancel2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        popupWindowSaveData2.dismiss();
                    }
                });
                checkBoxGaucher.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                        if(isChecked){
                            isGaucher = true;
                        }
                        else{
                            isGaucher = false;
                        }
                    }
                });
                buttonEquilibrageRoues.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        double rouedroite = 0.6;
                        double rouegauche = 0.6;
                        equilibrageRoues = Double.parseDouble(editTextCorrection.getText().toString());
                        sendMessage("d" + String.valueOf(rouedroite) + "w");
                        sendMessage("g" + String.valueOf(rouegauche) + "w");
                        metAjourEquilibrage(equilibrageRoues);
                    }
                });
                buttonFinTest.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        equilibrageRoues = Double.parseDouble(editTextCorrection.getText().toString());
                        sendMessage("d" + String.valueOf(0) + "w");
                        sendMessage("g" + String.valueOf(0) + "w");
                        metAjourEquilibrage(equilibrageRoues);
                    }
                });

                flecheGauche.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        equilibrageRoues = Double.parseDouble(editTextCorrection.getText().toString());
                        equilibrageRoues -= 0.2;
                        editTextCorrection.setText(String.valueOf(equilibrageRoues));
                        metAjourEquilibrage(equilibrageRoues);
                    }
                });
                flecheDroite.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        equilibrageRoues = Double.parseDouble(editTextCorrection.getText().toString());
                        equilibrageRoues += 0.2;
                        editTextCorrection.setText(String.valueOf(equilibrageRoues));
                        metAjourEquilibrage(equilibrageRoues);
                    }
                });
                buttonPopUpSave2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(reglage_direction.getText().length()<1 || tanh.getText().length()<1
                                || declenchementFeux.getText().length()<1)
                        {
                            Toast.makeText(getApplicationContext(), "Champs non complétés", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        sensibilite_angle = Double.parseDouble(reglage_direction.getText().toString());
                        sensibilite_rayon = Double.parseDouble(tanh.getText().toString());
                        niveau_declenchement_feux = Integer.parseInt(declenchementFeux.getText().toString());
                        sendMessage("l" + String.valueOf(100 - niveau_declenchement_feux) + "w");
                        popupWindowSaveData2.dismiss();
                    }
                });

            }
        });

        buttonMemory2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Clicked on light");
                sendMessage("f");
            }
        });

        buttonMemory3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked)  {    //manuel ?
                    sendMessage("m");
                    Toast.makeText(getApplicationContext(), "Feux en mode manuel", Toast.LENGTH_SHORT).show();
                }
                else {  //automatique
                    sendMessage("a");
                    Toast.makeText(getApplicationContext(), "Feux en mode automatique", Toast.LENGTH_SHORT).show();
                }
                if(isAllume){
                    buttonMemory2.setBackgroundResource(R.drawable.feux50);
                }
                else{
                    buttonMemory2.setBackgroundResource(R.drawable.feux_black50);
                }
            }
        });


        buttonReverse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "rappel de la voiture");
                //sendMessage("bouton 4");
                int taille = vitesse_roue_droite.size();
                for(int i = 0; i < taille;i++){
                    double droite = -vitesse_roue_droite.get(taille - i - 1);
                    double gauche = -vitesse_roue_gauche.get(taille - i - 1);
                    sendMessage("d" + String.valueOf(droite) + "w");
                    sendMessage("g" + String.valueOf(gauche) + "w");
                    Log.d(TAG, "date : "+new Date().getTime());
                    try {
                        Thread.sleep(45);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                vitesse_roue_droite.clear();
                vitesse_roue_gauche.clear();
            }
        });


        buttonDanse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Button eye of the tiger");
                sendMessage("t");
                MediaPlayer ring = MediaPlayer.create(MainActivity.this, R.raw.survivor_27sec);
                ring.start();

            }
        });


        buttonBTConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Button Click buttonBTConnect");

                if(bBTConnected==false) {
                    if (spinnerBTPairedDevices.getSelectedItemPosition() == 0) {
                        Log.d(TAG, "Please select BT device");
                        Toast.makeText(getApplicationContext(), "Please select Bluetooth Device", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String sSelectedDevice = spinnerBTPairedDevices.getSelectedItem().toString();
                    Log.d(TAG, "Selected device = " + sSelectedDevice);

                    for (BluetoothDevice BTDev : BTPairedDevices) {
                        if (sSelectedDevice.equals(BTDev.getName())) {
                            BTDevice = BTDev;
                            Log.d(TAG, "Selected device UUID = " + BTDevice.getAddress());

                            cBluetoothConnect cBTConnect = new cBluetoothConnect(BTDevice);
                            cBTConnect.start();

//
//                            try {
//                                Log.d(TAG, "Creating socket, my uuid " + MY_UUID);
//                                BTSocket = BTDevice.createRfcommSocketToServiceRecord(MY_UUID);
//                                Log.d(TAG, "Connecting to device");
//                                BTSocket.connect();
//                                Log.d(TAG, "Connected");
//                                buttonBTConnect.setText("Disconnect");
//                                bBTConnected = true;
//
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                                Log.e(TAG, "Exception = " + e.getMessage());
//                                bBTConnected = false;
//                            }


                        }
                    }
                }
                else {
                    Log.d(TAG, "Disconnecting BTConnection");
                    if(BTSocket!=null && BTSocket.isConnected())
                    {
                        try {
                            BTSocket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                            Log.d(TAG, "BTDisconnect Exp " + e.getMessage());
                        }
                    }
                    buttonBTConnect.setText("Connect");
                    bBTConnected = false;

                }
            }
        });
    }




    public class cBluetoothConnect extends Thread
    {
        private BluetoothDevice device;


        public cBluetoothConnect (BluetoothDevice BTDevice)
        {
            Log.i(TAG, "classBTConnect-start");

            device = BTDevice;
            try{
                BTSocket = device.createRfcommSocketToServiceRecord(MY_UUID);
            }
            catch (Exception exp)
            {
                Log.e(TAG, "classBTConnect-exp" + exp.getMessage());
            }
        }

        public void run()
        {
            try {
                BTSocket.connect();
                Message message=Message.obtain();
                message.what=BT_STATE_CONNECTED;
                handler.sendMessage(message);


            } catch (IOException e) {
                e.printStackTrace();
                Message message=Message.obtain();
                message.what=BT_STATE_CONNECTION_FAILED;
                handler.sendMessage(message);
            }
        }

    }


    public class classBTInitDataCommunication extends Thread
    {
        private final BluetoothSocket bluetoothSocket;
        private  InputStream inputStream =null;
        private  OutputStream outputStream=null;

        public classBTInitDataCommunication (BluetoothSocket socket)
        {
            Log.i(TAG, "classBTInitDataCommunication-start");

            bluetoothSocket=socket;


            try {
                inputStream=bluetoothSocket.getInputStream();
                outputStream=bluetoothSocket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
                Log.e(TAG, "classBTInitDataCommunication-start, exp " + e.getMessage());
            }


        }

        public void run()
        {
            byte[] buffer=new byte[1024];
            int bytes;

            while (BTSocket.isConnected())
            {
                try {
                    bytes=inputStream.read(buffer);
                    handler.obtainMessage(BT_STATE_MESSAGE_RECEIVED,bytes,-1,buffer).sendToTarget();
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e(TAG, "BT disconnect from decide end, exp " + e.getMessage());
                    iBTConnectionStatus=BT_CON_STATUS_CONNECTiON_LOST;
                    try {
                        //disconnect bluetooth
                        Log.d(TAG, "Disconnecting BTConnection");
                        if(BTSocket!=null && BTSocket.isConnected())
                        {

                            BTSocket.close();
                        }
                        buttonBTConnect.setText("Connect");
                        bBTConnected = false;
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }

                }
            }
        }

        public void write(byte[] bytes)
        {
            try {
                outputStream.write(bytes);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    Handler handler =new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {

            switch (msg.what)
            {
                case BT_STATE_LISTENING:
                    Log.d(TAG, "BT_STATE_LISTENING");
                    break;
                case BT_STATE_CONNECTING:
                    iBTConnectionStatus = BT_CON_STATUS_CONNECTING;
                    buttonBTConnect.setText("Connecting..");
                    Log.d(TAG, "BT_STATE_CONNECTING");
                    break;
                case BT_STATE_CONNECTED:

                    iBTConnectionStatus = BT_CON_STATUS_CONNECTED;

                    Log.d(TAG, "BT_CON_STATUS_CONNECTED");
                    buttonBTConnect.setText("Disconnect");

                    cBTInitSendReceive = new classBTInitDataCommunication(BTSocket);
                    cBTInitSendReceive.start();

                    bBTConnected = true;
                    break;
                case BT_STATE_CONNECTION_FAILED:
                    iBTConnectionStatus = BT_CON_STATUS_FAILED;
                    Log.d(TAG, "BT_STATE_CONNECTION_FAILED");
                    bBTConnected = false;
                    break;

                case BT_STATE_MESSAGE_RECEIVED:
                    byte[] readBuff= (byte[]) msg.obj;
                    String tempMsg=new String(readBuff,0,msg.arg1);

                    if(tempMsg.contains("F") && tempMsg.contains("f")){//on regarde l'etat des feux
                        int indexF = tempMsg.indexOf("F");
                        int indexf = tempMsg.indexOf("f");
                        String caractere_feux = tempMsg.substring(indexF+1,indexf);
                        if(caractere_feux.equals("F")){
                            buttonMemory2.setBackgroundResource(R.drawable.feux_black50);
                            isAllume = false;
                        }
                        else if(caractere_feux.equals("O")){
                            buttonMemory2.setBackgroundResource(R.drawable.feux50);
                            isAllume = true;
                        }
                        else{
                            Log.e(TAG, "Message feux non reconnu : "+caractere_feux);
                        }
                    }

                    if(tempMsg.contains("B") && tempMsg.contains("b")){//niveau de batterie de l'esp
                        int indexB = tempMsg.indexOf("B");
                        int indexW = tempMsg.indexOf("b");

                        double pourcentage = Double.parseDouble(tempMsg.substring(indexB+1,indexW));
                        editTextBatterie.setText(String.valueOf((int) pourcentage) + "%");
                    }
                    else{
                        Log.e(TAG, "Message non traited ( " + tempMsg.length() + " )  data : " + tempMsg);
                    }
                    Log.e(TAG, "Recu ( " + tempMsg.length() + " )  data : " + tempMsg);

                    if(tempMsg.contains("L") && tempMsg.contains("l")) {//niveau de batterie de l'esp
                        int indexL = tempMsg.indexOf("L");
                        int indexl = tempMsg.indexOf("l");
                        String luminosite_exterieure = tempMsg.substring(indexL+1,indexl);
                        textViewLuminosite.setText(luminosite_exterieure + "%");
                    }
                    break;

            }
            return true;
        }
    });


    public void sendMessage(String sMessage)
    {
        if( BTSocket!= null && iBTConnectionStatus==BT_CON_STATUS_CONNECTED)
        {
            if(BTSocket.isConnected() )
            {
                try {
                    Charset charset = StandardCharsets.UTF_8;
                    cBTInitSendReceive.write(sMessage.getBytes(charset));
                    Log.d(TAG, sMessage.getBytes(charset).toString());
                    Log.d(TAG, sMessage);
                }
                catch (Exception exp)
                {

                }
            }
        }
        else {
            temps2 = new Date().getTime();
            interval_temps = String.valueOf(temps2 - temps1);
            if(temps2 - temps1 > 2000){
                //Toast.makeText(getApplicationContext(), interval_temps, Toast.LENGTH_SHORT).show();
                Toast.makeText(getApplicationContext(), "connecte toi à la micro voiture", Toast.LENGTH_SHORT).show();
            }
            temps1 = temps2;
        }

    }

    void getBTPairedDevices()
    {
        Log.d(TAG, "getBTPairedDevices - start ");
        BTAdaptor = BluetoothAdapter.getDefaultAdapter();
        if(BTAdaptor == null)
        {
            Log.e(TAG, "getBTPairedDevices , BTAdaptor null ");
            editTextSentMessage.setText("\nNo Bluetooth Device in the phone");
            return;

        }

        if(!BTAdaptor.isEnabled())
        {
            Log.e(TAG, "getBTPairedDevices , BT not enabled");
            Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnOn, 0);
            Toast.makeText(getApplicationContext(), "Activation Bluetooth",Toast.LENGTH_LONG).show();

            return;
        }

        BTPairedDevices = BTAdaptor.getBondedDevices();
        Log.d(TAG, "getBTPairedDevices , Paired devices count = " + BTPairedDevices.size());

        for (BluetoothDevice BTDev : BTPairedDevices)
        {
            Log.d(TAG, BTDev.getName() + ", " + BTDev.getAddress());
        }


    }

    void populateSpinnerWithBTPairedDevices()
    {
        ArrayList<String> alPairedDevices = new ArrayList<>();
        alPairedDevices.add("Select");
        for (BluetoothDevice BTDev : BTPairedDevices)
        {
            alPairedDevices.add(BTDev.getName());
        }

        final ArrayAdapter<String> aaPairedDevices = new ArrayAdapter<String>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,alPairedDevices);
        aaPairedDevices.setDropDownViewResource(androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        spinnerBTPairedDevices.setAdapter(aaPairedDevices);
    }


    @Override
    protected void onResume() {
        super.onResume();

        Log.d(TAG, "onResume-Resume");

        getBTPairedDevices();
        populateSpinnerWithBTPairedDevices();


    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.d(TAG, "onPause-Start");

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BTAdaptor.disable();
        Log.d(TAG, "bluetooth desactivee");
        Log.d(TAG, "onDestroy");
    }
}